using System.Drawing;
using System.Windows.Forms;

namespace ola
{
    internal static class TemaAplicacao
    {
        private static readonly Color Fundo = Color.FromArgb(245, 247, 250);
        private static readonly Color Texto = Color.FromArgb(31, 41, 55);
        private static readonly Color Primaria = Color.FromArgb(23, 92, 211);
        private static readonly Color Perigo = Color.FromArgb(190, 45, 55);

        public static void Aplicar(Form formulario)
        {
            formulario.BackColor = Fundo;
            formulario.ForeColor = Texto;
            formulario.Font = new Font("Segoe UI", 10F, FontStyle.Regular);
            formulario.StartPosition = FormStartPosition.CenterScreen;
            formulario.MinimumSize = formulario.Size;
            AplicarControles(formulario.Controls);
        }

        private static void AplicarControles(Control.ControlCollection controles)
        {
            foreach (Control controle in controles)
            {
                Button botao = controle as Button;
                if (botao != null)
                {
                    botao.FlatStyle = FlatStyle.Flat;
                    botao.FlatAppearance.BorderSize = 0;
                    botao.Cursor = Cursors.Hand;
                    botao.BackColor = botao.Text == "Excluir" || botao.Text == "Sair" ? Perigo : Primaria;
                    botao.ForeColor = Color.White;
                    botao.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
                }

                TextBox campo = controle as TextBox;
                if (campo != null)
                {
                    campo.BorderStyle = BorderStyle.FixedSingle;
                    campo.BackColor = campo.ReadOnly ? Color.FromArgb(232, 236, 241) : Color.White;
                }

                DataGridView grade = controle as DataGridView;
                if (grade != null)
                {
                    grade.BackgroundColor = Color.White;
                    grade.BorderStyle = BorderStyle.None;
                    grade.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    grade.EnableHeadersVisualStyles = false;
                    grade.ColumnHeadersDefaultCellStyle.BackColor = Primaria;
                    grade.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                    grade.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
                    grade.RowHeadersVisible = false;
                    grade.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                }

                if (controle.HasChildren) AplicarControles(controle.Controls);
            }
        }
    }
}

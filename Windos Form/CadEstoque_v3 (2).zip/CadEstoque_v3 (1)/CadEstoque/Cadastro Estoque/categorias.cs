﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace ola
{
    public partial class categorias : Form
    {
        public categorias()
        {
            InitializeComponent();
            TemaAplicacao.Aplicar(this);
        }

        private void Close_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void categorias_Load(object sender, EventArgs e)
        {
            Categorias();
        }
        private void Categorias()
        {
            string connectionString = "Server=localhost;Port=3306;Database=Estoque;Uid=root;Pwd=;";

            string sql = @"SELECT p.nm_produto AS Produto, c.nm_categoria AS Categoria
                   FROM produtos p
                   INNER JOIN produto_categoria pc ON p.cd_produto = pc.id_produto
                   INNER JOIN categorias c ON pc.id_categoria = c.cd_categoria";

            using (var conn = new MySqlConnection(connectionString))
            {
                var adapter = new MySqlDataAdapter(sql, conn);
                var tabela = new DataTable();
                adapter.Fill(tabela);
                dataGridView1.DataSource = tabela;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ola
{
    public partial class index : Form
    {
        public index()
        {
            InitializeComponent();
            TemaAplicacao.Aplicar(this);
        }


        private void AbrirCadastroUsuarios(object sender, EventArgs e)
        {
            using (CadastroUsuario formulario = new CadastroUsuario())
            {
                formulario.ShowDialog(this);
            }
        }

        private void tabelaDasComprasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            using (Compras formCompra = new Compras())
            {
                formCompra.ShowDialog(this);
            }
        }

       

        private void Fornecedores_Click(object sender, EventArgs e)
        {
            using (Fornecedor formFornecedor = new Fornecedor())
            {
                formFornecedor.ShowDialog(this);
            }
        }

        private void categorias_Click(object sender, EventArgs e)
        {
            using (categorias FormCategoria = new categorias())
            {
                FormCategoria.ShowDialog(this);
            }
        }

       

        private void index_Load(object sender, EventArgs e)
        {
          
            // Exibir (telas de tabela já existentes)
            tabelaDasComprasToolStripMenuItem.Click += toolStripButton1_Click;
            tabelaDeFornecedoresToolStripMenuItem.Click += Fornecedores_Click;
            tabelaDeCategoriasToolStripMenuItem.Click += categorias_Click;

            // Cadastrar
            comprasToolStripMenuItem.DropDownItems.Insert(0, new ToolStripMenuItem("Cadastrar compra", null, (s, a) => AbrirCadastro(CadastroTabela.Compras())));
            comprasToolStripMenuItem.DropDownItems.Insert(1, new ToolStripMenuItem("Itens da compra", null, (s, a) => AbrirCadastro(CadastroTabela.ItensCompra())));
            fornecedoresToolStripMenuItem.DropDownItems.Insert(0, new ToolStripMenuItem("Cadastrar fornecedor", null, (s, a) => AbrirCadastro(CadastroTabela.Fornecedores())));
            categoriasToolStripMenuItem.DropDownItems.Insert(0, new ToolStripMenuItem("Cadastrar categoria", null, (s, a) => AbrirCadastro(CadastroTabela.Categorias())));
            categoriasToolStripMenuItem.DropDownItems.Insert(1, new ToolStripMenuItem("Ligar produto a categoria", null, (s, a) => AbrirCadastro(CadastroTabela.ProdutoCategoria())));

            AdicionarMenu("Produtos", new ToolStripMenuItem("Cadastrar / exibir produtos", null, (s, a) => AbrirCadastro(CadastroTabela.Produtos())));
            AdicionarMenu("Vendas",
                new ToolStripMenuItem("Cadastrar venda", null, (s, a) => AbrirCadastro(CadastroTabela.Vendas())),
                new ToolStripMenuItem("Itens da venda", null, (s, a) => AbrirCadastro(CadastroTabela.ItensVenda())));
            AdicionarMenu("Funcionários", new ToolStripMenuItem("Cadastrar / exibir funcionários", null, (s, a) => AbrirCadastro(CadastroTabela.Funcionarios())));
            AdicionarMenu("Usuários", new ToolStripMenuItem("Cadastrar / exibir usuários", null, (s, a) => AbrirCadastro(CadastroTabela.Usuarios())));
        }

        private void AdicionarMenu(string titulo, params ToolStripItem[] itens)
        {
            ToolStripMenuItem menu = new ToolStripMenuItem(titulo);
            menu.ForeColor = Color.White;
            menu.DropDownItems.AddRange(itens);
            menuStrip1.Items.Add(menu);
        }

        private void AbrirCadastro(Form formulario)
        {
            using (formulario)
            {
                formulario.ShowDialog(this);
            }
        }

        private void SairJackpot_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace ola
{
    public partial class Compras : Form
    {
        public Compras()
        {
            InitializeComponent();
            TemaAplicacao.Aplicar(this);
        }

        private void Close_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Compras_Load(object sender, EventArgs e)
        {
            CarregarCompras();
        }
        private void CarregarCompras()
        {
            string connectionString = "Server=localhost;Port=3306;Database=Estoque;Uid=root;Pwd=;";

            try
            {
                using (var conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = @"SELECT c.cd_compra AS Compra, c.dt_compra AS Data, p.nm_produto AS Produto, ic.qt_produto AS Quantidade, ic.vl_unitario AS `Valor unit.`
                                   FROM compras c
                                   INNER JOIN itens_compra ic ON c.cd_compra = ic.id_compra
                                   INNER JOIN produtos p ON ic.id_produto = p.cd_produto";  

                    using (var adapter = new MySqlDataAdapter(sql, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        dataGridView1.DataSource = dt; 
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar dados: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

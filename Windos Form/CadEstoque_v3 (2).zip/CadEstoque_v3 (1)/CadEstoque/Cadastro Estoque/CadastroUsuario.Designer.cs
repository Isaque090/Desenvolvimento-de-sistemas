﻿namespace ola
{
    partial class CadastroUsuario
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblNivel;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.Label lblSenha;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.ComboBox cmbNivel;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.Button btnNovo;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Button btnExcluir;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.Button btnPrimeiro;
        private System.Windows.Forms.Button btnAnterior;
        private System.Windows.Forms.Button btnProximo;
        private System.Windows.Forms.Button btnUltimo;
        private System.Windows.Forms.Button btnSair;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblCodigo = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblNivel = new System.Windows.Forms.Label();
            this.lblLogin = new System.Windows.Forms.Label();
            this.lblSenha = new System.Windows.Forms.Label();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.cmbNivel = new System.Windows.Forms.ComboBox();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.btnNovo = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.btnEditar = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.btnPrimeiro = new System.Windows.Forms.Button();
            this.btnAnterior = new System.Windows.Forms.Button();
            this.btnProximo = new System.Windows.Forms.Button();
            this.btnUltimo = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // labels
            this.lblCodigo.AutoSize = true; this.lblCodigo.Location = new System.Drawing.Point(42, 92); this.lblCodigo.Text = "Código";
            this.lblNome.AutoSize = true; this.lblNome.Location = new System.Drawing.Point(42, 140); this.lblNome.Text = "Nome";
            this.lblNivel.AutoSize = true; this.lblNivel.Location = new System.Drawing.Point(42, 188); this.lblNivel.Text = "Nível";
            this.lblLogin.AutoSize = true; this.lblLogin.Location = new System.Drawing.Point(42, 236); this.lblLogin.Text = "Login";
            this.lblSenha.AutoSize = true; this.lblSenha.Location = new System.Drawing.Point(42, 284); this.lblSenha.Text = "Senha";
            // fields
            this.txtCodigo.Location = new System.Drawing.Point(140, 86); this.txtCodigo.Name = "txtCodigo"; this.txtCodigo.Size = new System.Drawing.Size(90, 27); this.txtCodigo.TabIndex = 0; this.txtCodigo.ReadOnly = true;
            this.txtNome.Location = new System.Drawing.Point(140, 134); this.txtNome.Name = "txtNome"; this.txtNome.Size = new System.Drawing.Size(330, 27); this.txtNome.TabIndex = 1;
            this.cmbNivel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList; this.cmbNivel.FormattingEnabled = true; this.cmbNivel.Items.AddRange(new object[] { "Usuário", "Administrador", "Operador" }); this.cmbNivel.Location = new System.Drawing.Point(140, 182); this.cmbNivel.Name = "cmbNivel"; this.cmbNivel.Size = new System.Drawing.Size(190, 28); this.cmbNivel.TabIndex = 2;
            this.txtLogin.Location = new System.Drawing.Point(140, 230); this.txtLogin.Name = "txtLogin"; this.txtLogin.Size = new System.Drawing.Size(260, 27); this.txtLogin.TabIndex = 3;
            this.txtSenha.Location = new System.Drawing.Point(140, 278); this.txtSenha.Name = "txtSenha"; this.txtSenha.PasswordChar = '*'; this.txtSenha.Size = new System.Drawing.Size(260, 27); this.txtSenha.TabIndex = 4;
            // first row
            this.btnNovo.Location = new System.Drawing.Point(42, 342); this.btnNovo.Name = "btnNovo"; this.btnNovo.Size = new System.Drawing.Size(82, 34); this.btnNovo.TabIndex = 5; this.btnNovo.Text = "Novo"; this.btnNovo.UseVisualStyleBackColor = true; this.btnNovo.Click += new System.EventHandler(this.btnNovo_Click);
            this.btnSalvar.Location = new System.Drawing.Point(132, 342); this.btnSalvar.Name = "btnSalvar"; this.btnSalvar.Size = new System.Drawing.Size(82, 34); this.btnSalvar.TabIndex = 6; this.btnSalvar.Text = "Salvar"; this.btnSalvar.UseVisualStyleBackColor = true; this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            this.btnEditar.Location = new System.Drawing.Point(222, 342); this.btnEditar.Name = "btnEditar"; this.btnEditar.Size = new System.Drawing.Size(82, 34); this.btnEditar.TabIndex = 7; this.btnEditar.Text = "Editar"; this.btnEditar.UseVisualStyleBackColor = true; this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            this.btnExcluir.Location = new System.Drawing.Point(312, 342); this.btnExcluir.Name = "btnExcluir"; this.btnExcluir.Size = new System.Drawing.Size(82, 34); this.btnExcluir.TabIndex = 8; this.btnExcluir.Text = "Excluir"; this.btnExcluir.UseVisualStyleBackColor = true; this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            this.btnConsultar.Location = new System.Drawing.Point(402, 342); this.btnConsultar.Name = "btnConsultar"; this.btnConsultar.Size = new System.Drawing.Size(88, 34); this.btnConsultar.TabIndex = 9; this.btnConsultar.Text = "Consultar"; this.btnConsultar.UseVisualStyleBackColor = true; this.btnConsultar.Click += new System.EventHandler(this.btnConsultar_Click);
            // second row
            this.btnPrimeiro.Location = new System.Drawing.Point(42, 386); this.btnPrimeiro.Name = "btnPrimeiro"; this.btnPrimeiro.Size = new System.Drawing.Size(82, 34); this.btnPrimeiro.TabIndex = 10; this.btnPrimeiro.Text = "Primeiro"; this.btnPrimeiro.UseVisualStyleBackColor = true; this.btnPrimeiro.Click += new System.EventHandler(this.btnPrimeiro_Click);
            this.btnAnterior.Location = new System.Drawing.Point(132, 386); this.btnAnterior.Name = "btnAnterior"; this.btnAnterior.Size = new System.Drawing.Size(82, 34); this.btnAnterior.TabIndex = 11; this.btnAnterior.Text = "Anterior"; this.btnAnterior.UseVisualStyleBackColor = true; this.btnAnterior.Click += new System.EventHandler(this.btnAnterior_Click);
            this.btnProximo.Location = new System.Drawing.Point(222, 386); this.btnProximo.Name = "btnProximo"; this.btnProximo.Size = new System.Drawing.Size(82, 34); this.btnProximo.TabIndex = 12; this.btnProximo.Text = "Próximo"; this.btnProximo.UseVisualStyleBackColor = true; this.btnProximo.Click += new System.EventHandler(this.btnProximo_Click);
            this.btnUltimo.Location = new System.Drawing.Point(312, 386); this.btnUltimo.Name = "btnUltimo"; this.btnUltimo.Size = new System.Drawing.Size(82, 34); this.btnUltimo.TabIndex = 13; this.btnUltimo.Text = "Último"; this.btnUltimo.UseVisualStyleBackColor = true; this.btnUltimo.Click += new System.EventHandler(this.btnUltimo_Click);
            this.btnSair.Location = new System.Drawing.Point(402, 386); this.btnSair.Name = "btnSair"; this.btnSair.Size = new System.Drawing.Size(88, 34); this.btnSair.TabIndex = 14; this.btnSair.Text = "Sair"; this.btnSair.UseVisualStyleBackColor = true; this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // form
            this.AcceptButton = this.btnSalvar;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(535, 455);
            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.lblCodigo, this.lblNome, this.lblNivel, this.lblLogin, this.lblSenha, this.txtCodigo, this.txtNome, this.cmbNivel, this.txtLogin, this.txtSenha, this.btnNovo, this.btnSalvar, this.btnEditar, this.btnExcluir, this.btnConsultar, this.btnPrimeiro, this.btnAnterior, this.btnProximo, this.btnUltimo, this.btnSair });
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "CadastroUsuario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gestão de Usuários";
            this.Load += new System.EventHandler(this.CadastroUsuario_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}

﻿namespace ola
{
    partial class index
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.comprasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabelaDasComprasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fornecedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabelaDeFornecedoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoriasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabelaDeCategoriasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Sair3 = new System.Windows.Forms.Button();
            this.SairJackpot = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Firebrick;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comprasToolStripMenuItem,
            this.fornecedoresToolStripMenuItem,
            this.categoriasToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(759, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // comprasToolStripMenuItem
            // 
            this.comprasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tabelaDasComprasToolStripMenuItem});
            this.comprasToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.comprasToolStripMenuItem.Name = "comprasToolStripMenuItem";
            this.comprasToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.comprasToolStripMenuItem.Text = "Compras";
            // 
            // tabelaDasComprasToolStripMenuItem
            // 
            this.tabelaDasComprasToolStripMenuItem.Name = "tabelaDasComprasToolStripMenuItem";
            this.tabelaDasComprasToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.tabelaDasComprasToolStripMenuItem.Text = "Tabela das compras";
            this.tabelaDasComprasToolStripMenuItem.Click += new System.EventHandler(this.tabelaDasComprasToolStripMenuItem_Click);
            // 
            // fornecedoresToolStripMenuItem
            // 
            this.fornecedoresToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tabelaDeFornecedoresToolStripMenuItem});
            this.fornecedoresToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.fornecedoresToolStripMenuItem.Name = "fornecedoresToolStripMenuItem";
            this.fornecedoresToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.fornecedoresToolStripMenuItem.Text = "Fornecedores";
            // 
            // tabelaDeFornecedoresToolStripMenuItem
            // 
            this.tabelaDeFornecedoresToolStripMenuItem.Name = "tabelaDeFornecedoresToolStripMenuItem";
            this.tabelaDeFornecedoresToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.tabelaDeFornecedoresToolStripMenuItem.Text = "tabela de fornecedores";
            // 
            // categoriasToolStripMenuItem
            // 
            this.categoriasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tabelaDeCategoriasToolStripMenuItem});
            this.categoriasToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.categoriasToolStripMenuItem.Name = "categoriasToolStripMenuItem";
            this.categoriasToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.categoriasToolStripMenuItem.Text = "categorias";
            // 
            // tabelaDeCategoriasToolStripMenuItem
            // 
            this.tabelaDeCategoriasToolStripMenuItem.Name = "tabelaDeCategoriasToolStripMenuItem";
            this.tabelaDeCategoriasToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.tabelaDeCategoriasToolStripMenuItem.Text = "tabela de categorias";
            // 
            // Sair3
            // 
            this.Sair3.Location = new System.Drawing.Point(668, 321);
            this.Sair3.Name = "Sair3";
            this.Sair3.Size = new System.Drawing.Size(8, 8);
            this.Sair3.TabIndex = 5;
            this.Sair3.Text = "Sair";
            this.Sair3.UseVisualStyleBackColor = true;
            // 
            // SairJackpot
            // 
            this.SairJackpot.Location = new System.Drawing.Point(575, 321);
            this.SairJackpot.Name = "SairJackpot";
            this.SairJackpot.Size = new System.Drawing.Size(161, 48);
            this.SairJackpot.TabIndex = 6;
            this.SairJackpot.Text = "Sair";
            this.SairJackpot.UseVisualStyleBackColor = true;
            this.SairJackpot.Click += new System.EventHandler(this.SairJackpot_Click);
            // 
            // index
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(759, 411);
            this.Controls.Add(this.SairJackpot);
            this.Controls.Add(this.Sair3);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "index";
            this.Text = "index";
            this.Load += new System.EventHandler(this.index_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem comprasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fornecedoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem categoriasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tabelaDasComprasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tabelaDeFornecedoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tabelaDeCategoriasToolStripMenuItem;
        private System.Windows.Forms.Button Sair3;
        private System.Windows.Forms.Button SairJackpot;
    }
}
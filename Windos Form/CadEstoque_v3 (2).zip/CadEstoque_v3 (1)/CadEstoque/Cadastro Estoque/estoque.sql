CREATE DATABASE Estoque;
USE Estoque;

CREATE TABLE Produtos(
    cd_produto INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    nm_produto VARCHAR(80) NOT NULL,
    vl_produto DECIMAL(10,2) NOT NULL,
    dt_validade_produto DATE NOT NULL,
    ds_produto VARCHAR(255) NOT NULL,
    qt_estoque INT NOT NULL DEFAULT 0
);


CREATE TABLE fornecedores (
    cd_fornecedor INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    nm_fornecedor VARCHAR(100) NOT NULL,
    ds_telefone VARCHAR(20) NOT NULL,
    ds_email VARCHAR(100) NOT NULL
);


-- e na onde os produtos vão fica, pq n ´pode deixar bagunçado, exemplo(categorias: comida, limpeza, higiene, congelador
CREATE TABLE Categorias(
    cd_categoria INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    nm_categoria VARCHAR(80) NOT NULL,
    ds_categoria VARCHAR(255),
    status ENUM('ativo', 'inativo') DEFAULT 'ativo'
);



CREATE TABLE Funcionarios (
    cd_funcionario INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    nm_funcionario VARCHAR(100) NOT NULL,
    dt_nascimento DATE NOT NULL,
    ds_telefone VARCHAR(20),
    ds_email VARCHAR(100),
    ds_cargo ENUM('admin', 'vendedor', 'estoquista') DEFAULT 'vendedor',
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    ds_senha VARCHAR(155) NOT NULL
);

CREATE TABLE Usuarios (
    cd_usuario INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    nm_usuario VARCHAR(100) NOT NULL,
    dt_nascimento DATE NOT NULL,
    ds_telefone VARCHAR(20),
    ds_email VARCHAR(100)
    
);

CREATE TABLE compras (
    cd_compra INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    dt_compra DATETIME NOT NULL,
    vl_total DECIMAL(10,2) NOT NULL,
    id_funcionario INT NOT NULL,
    id_fornecedor INT NOT NULL,

    FOREIGN KEY (id_funcionario)
        REFERENCES funcionarios(cd_funcionario),

    FOREIGN KEY (id_fornecedor)
        REFERENCES fornecedores(cd_fornecedor)
);



CREATE TABLE vendas (
    cd_venda INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    dt_venda DATETIME NOT NULL,
    vl_total DECIMAL(10,2) NOT NULL,
    id_funcionario INT NOT NULL,

    FOREIGN KEY (id_funcionario)
        REFERENCES funcionarios(cd_funcionario)
);


CREATE TABLE produto_categoria (
    id_produto_categoria INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    id_produto INT NOT NULL,
    id_categoria INT NOT NULL,

    FOREIGN KEY (id_produto)
        REFERENCES Produtos(cd_produto),

    FOREIGN KEY (id_categoria)
        REFERENCES Categorias(cd_categoria)
);


CREATE TABLE itens_compra (
    id_item_compra INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    id_compra INT NOT NULL,
    id_produto INT NOT NULL,
    qt_produto INT NOT NULL,
    vl_unitario DECIMAL(10,2) NOT NULL,

    FOREIGN KEY (id_compra)
        REFERENCES Compras(cd_compra),

    FOREIGN KEY (id_produto)
        REFERENCES Produtos(cd_produto)
);


CREATE TABLE itens_venda (
    id_item_venda INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
    id_venda INT NOT NULL,
    id_produto INT NOT NULL,
    quantidade INT NOT NULL,
    vl_unitario DECIMAL(10,2) NOT NULL,

    FOREIGN KEY (id_venda)
        REFERENCES Vendas(cd_venda),

    FOREIGN KEY (id_produto)
        REFERENCES Produtos(cd_produto)
);



SELECT p.nm_produto, c.nm_categoria
FROM produtos p
INNER JOIN produto_categoria pc 
    ON p.cd_produto = pc.id_produto
INNER JOIN categorias c 
    ON pc.id_categoria = c.cd_categoria;


SELECT c.cd_compra, p.nm_produto, qt_produto, ic.vl_unitario
FROM compras c
INNER JOIN itens_compra ic 
    ON c.cd_compra = ic.id_compra
INNER JOIN produtos p 
    ON ic.id_produto = p.cd_produto;

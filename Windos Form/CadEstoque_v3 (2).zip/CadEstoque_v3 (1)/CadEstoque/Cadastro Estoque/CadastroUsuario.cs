﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ola
{
    public partial class CadastroUsuario : Form
    {
        private const string ConnectionString = "Server=localhost;Port=3306;Database=Estoque;Uid=root;Pwd=;";
        private readonly List<int> codigos = new List<int>();
        private int indiceAtual = -1;

        public CadastroUsuario()
        {
            InitializeComponent();
            TemaAplicacao.Aplicar(this);
        }

        private void CadastroUsuario_Load(object sender, EventArgs e)
        {
            try
            {
                CriarTabelaSeNecessario();
                CarregarCodigos();
                NovoCadastro();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível conectar ao banco de dados.\n" + ex.Message,
                    "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private MySqlConnection CriarConexao()
        {
            return new MySqlConnection(ConnectionString);
        }

        private void CriarTabelaSeNecessario()
        {
            const string sql = @"CREATE TABLE IF NOT EXISTS Usuarios (
                cd_usuario INT UNSIGNED NOT NULL AUTO_INCREMENT,
                nm_usuario VARCHAR(120) NOT NULL,
                ds_nivel ENUM('Usuário', 'Administrador', 'Operador') NOT NULL DEFAULT 'Usuário',
                ds_login VARCHAR(80) NOT NULL,
                ds_senha VARCHAR(255) NOT NULL,
                dt_criacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (cd_usuario),
                UNIQUE KEY uk_usuarios_login (ds_login)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

            using (MySqlConnection conexao = CriarConexao())
            using (MySqlCommand comando = new MySqlCommand(sql, conexao))
            {
                conexao.Open();
                comando.ExecuteNonQuery();
            }
        }

        private void CarregarCodigos()
        {
            codigos.Clear();
            using (MySqlConnection conexao = CriarConexao())
            using (MySqlCommand comando = new MySqlCommand("SELECT cd_usuario FROM Usuarios ORDER BY cd_usuario", conexao))
            {
                conexao.Open();
                using (MySqlDataReader leitor = comando.ExecuteReader())
                {
                    while (leitor.Read()) codigos.Add(leitor.GetInt32(0));
                }
            }
        }

        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text))
            {
                MessageBox.Show("Informe o nome do usuário.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNome.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(cmbNivel.Text))
            {
                MessageBox.Show("Selecione o nível do usuário.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbNivel.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtLogin.Text))
            {
                MessageBox.Show("Informe o login do usuário.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLogin.Focus();
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtSenha.Text) || txtSenha.Text.Length < 4)
            {
                MessageBox.Show("A senha deve ter no mínimo 4 caracteres.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSenha.Focus();
                return false;
            }
            return true;
        }

        private void NovoCadastro()
        {
            indiceAtual = -1;
            txtCodigo.Clear();
            txtNome.Clear();
            cmbNivel.SelectedIndex = 0;
            txtLogin.Clear();
            txtSenha.Clear();
            txtNome.Focus();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            NovoCadastro();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos()) return;

            try
            {
                bool editando = !string.IsNullOrWhiteSpace(txtCodigo.Text);
                string sql = editando
                    ? @"UPDATE Usuarios SET nm_usuario=@nome, ds_nivel=@nivel, ds_login=@login, ds_senha=@senha WHERE cd_usuario=@codigo"
                    : @"INSERT INTO Usuarios (nm_usuario, ds_nivel, ds_login, ds_senha) VALUES (@nome, @nivel, @login, @senha)";

                using (MySqlConnection conexao = CriarConexao())
                using (MySqlCommand comando = new MySqlCommand(sql, conexao))
                {
                    comando.Parameters.AddWithValue("@nome", txtNome.Text.Trim());
                    comando.Parameters.AddWithValue("@nivel", cmbNivel.Text);
                    comando.Parameters.AddWithValue("@login", txtLogin.Text.Trim());
                    comando.Parameters.AddWithValue("@senha", txtSenha.Text);
                    if (editando) comando.Parameters.AddWithValue("@codigo", Convert.ToInt32(txtCodigo.Text));
                    conexao.Open();
                    comando.ExecuteNonQuery();
                    if (!editando) txtCodigo.Text = comando.LastInsertedId.ToString();
                }

                CarregarCodigos();
                indiceAtual = codigos.IndexOf(Convert.ToInt32(txtCodigo.Text));
                MessageBox.Show("Usuário salvo com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (MySqlException ex)
            {
                string mensagem = ex.Number == 1062 ? "Este login já está cadastrado." : ex.Message;
                MessageBox.Show("Erro ao salvar o usuário.\n" + mensagem, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodigo.Text))
            {
                MessageBox.Show("Consulte um usuário antes de editar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            txtNome.Focus();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodigo.Text))
            {
                MessageBox.Show("Consulte um usuário antes de excluir.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (MessageBox.Show("Deseja excluir este usuário?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            try
            {
                using (MySqlConnection conexao = CriarConexao())
                using (MySqlCommand comando = new MySqlCommand("DELETE FROM Usuarios WHERE cd_usuario=@codigo", conexao))
                {
                    comando.Parameters.AddWithValue("@codigo", Convert.ToInt32(txtCodigo.Text));
                    conexao.Open();
                    comando.ExecuteNonQuery();
                }
                CarregarCodigos();
                NovoCadastro();
                MessageBox.Show("Usuário excluído com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir o usuário.\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            int codigo;
            if (!int.TryParse(txtCodigo.Text, out codigo))
            {
                MessageBox.Show("Informe o código que deseja consultar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCodigo.Focus();
                return;
            }
            ExibirUsuario(codigo);
        }

        private void ExibirUsuario(int codigo)
        {
            try
            {
                using (MySqlConnection conexao = CriarConexao())
                using (MySqlCommand comando = new MySqlCommand("SELECT cd_usuario, nm_usuario, ds_nivel, ds_login, ds_senha FROM Usuarios WHERE cd_usuario=@codigo", conexao))
                {
                    comando.Parameters.AddWithValue("@codigo", codigo);
                    conexao.Open();
                    using (MySqlDataReader leitor = comando.ExecuteReader())
                    {
                        if (!leitor.Read())
                        {
                            MessageBox.Show("Usuário não encontrado.", "Consulta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                        txtCodigo.Text = leitor.GetInt32(0).ToString();
                        txtNome.Text = leitor.GetString(1);
                        cmbNivel.Text = leitor.GetString(2);
                        txtLogin.Text = leitor.GetString(3);
                        txtSenha.Text = leitor.GetString(4);
                    }
                }
                indiceAtual = codigos.IndexOf(codigo);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao consultar o usuário.\n" + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnPrimeiro_Click(object sender, EventArgs e)
        {
            if (codigos.Count == 0) return;
            indiceAtual = 0;
            ExibirUsuario(codigos[indiceAtual]);
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            if (codigos.Count == 0) return;
            indiceAtual = indiceAtual <= 0 ? 0 : indiceAtual - 1;
            ExibirUsuario(codigos[indiceAtual]);
        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            if (codigos.Count == 0) return;
            indiceAtual = indiceAtual < 0 ? 0 : Math.Min(indiceAtual + 1, codigos.Count - 1);
            ExibirUsuario(codigos[indiceAtual]);
        }

        private void btnUltimo_Click(object sender, EventArgs e)
        {
            if (codigos.Count == 0) return;
            indiceAtual = codigos.Count - 1;
            ExibirUsuario(codigos[indiceAtual]);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

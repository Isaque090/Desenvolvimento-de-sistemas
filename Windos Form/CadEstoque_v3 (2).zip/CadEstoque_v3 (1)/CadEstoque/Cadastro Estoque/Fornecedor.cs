﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySqlConnector;

namespace ola
{
    public partial class Fornecedor : Form
    {
        public Fornecedor()
        {
            InitializeComponent();
            TemaAplicacao.Aplicar(this);
        }

        private void Fornecedor_Load(object sender, EventArgs e)
        {
            CarregarGrid();
        }

        private void Close_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void CarregarGrid()
        {
            string connectionString = "Server=localhost;Port=3306;Database=Estoque;Uid=root;Pwd=;";

            string sql = @"SELECT cd_fornecedor AS Código,
                          nm_fornecedor AS Fornecedor,
                          ds_telefone   AS Telefone,
                          ds_email      AS Email
                   FROM fornecedores";

            try
            {
                using (var conn = new MySqlConnection(connectionString))
                {
                    var adapter = new MySqlDataAdapter(sql, conn);
                    var tabela = new DataTable();
                    adapter.Fill(tabela);
                    dataGridView1.DataSource = tabela;

                }

                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dataGridView1.ReadOnly = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

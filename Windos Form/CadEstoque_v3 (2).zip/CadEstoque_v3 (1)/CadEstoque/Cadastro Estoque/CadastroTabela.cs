using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using MySqlConnector;

namespace ola
{
    public enum TipoCampo { Texto, Inteiro, Decimal, Data, Lista }

    public class CampoCadastro
    {
        public string Coluna;
        public string Rotulo;
        public TipoCampo Tipo;
        public bool Obrigatorio;
        public string SqlLista; // SELECT id, nome FROM ... (apenas para TipoCampo.Lista)

        public CampoCadastro(string coluna, string rotulo, TipoCampo tipo, bool obrigatorio = false, string sqlLista = null)
        {
            Coluna = coluna; Rotulo = rotulo; Tipo = tipo; Obrigatorio = obrigatorio; SqlLista = sqlLista;
        }
    }

    /// <summary>
    /// Tela genérica de cadastro: formulário para cadastrar/editar/excluir
    /// e grade para exibir os registros da tabela.
    /// </summary>
    public class CadastroTabela : Form
    {
        private const string ConnectionString = "Server=localhost;Port=3306;Database=Estoque;Uid=root;Pwd=;";

        private readonly string tabela;
        private readonly string chave;
        private readonly string sqlExibir;
        private readonly List<CampoCadastro> campos;
        private readonly Dictionary<string, Control> editores = new Dictionary<string, Control>();

        private TextBox txtCodigo;
        private TextBox txtBusca;
        private DataGridView grid;
        private DataTable dados;

        public CadastroTabela(string titulo, string tabela, string chave, string sqlExibir, List<CampoCadastro> campos)
        {
            this.tabela = tabela;
            this.chave = chave;
            this.sqlExibir = sqlExibir;
            this.campos = campos;

            Text = titulo;
            StartPosition = FormStartPosition.CenterParent;
            Size = new Size(980, 640);
            MinimumSize = new Size(820, 520);
            Font = new Font("Segoe UI", 9.5f);

            MontarTela(titulo);
            TemaAplicacao.Aplicar(this);
            Load += (s, e) => { CarregarListas(); CarregarGrid(); };
        }

        private void MontarTela(string titulo)
        {
            var lblTitulo = new Label
            {
                Text = titulo,
                Dock = DockStyle.Top,
                Height = 48,
                Font = new Font("Segoe UI Semibold", 15f),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(16, 0, 0, 0)
            };

            // ---- Painel de cadastro (esquerda) ----
            var painel = new Panel { Dock = DockStyle.Left, Width = 330, Padding = new Padding(16), AutoScroll = true };
            int y = 8;

            painel.Controls.Add(new Label { Text = "Código", Location = new Point(16, y), AutoSize = true });
            txtCodigo = new TextBox { Location = new Point(16, y + 20), Width = 280, ReadOnly = true };
            painel.Controls.Add(txtCodigo);
            y += 56;

            foreach (var c in campos)
            {
                painel.Controls.Add(new Label { Text = c.Rotulo + (c.Obrigatorio ? " *" : ""), Location = new Point(16, y), AutoSize = true });
                Control editor;
                switch (c.Tipo)
                {
                    case TipoCampo.Data:
                        editor = new DateTimePicker { Format = DateTimePickerFormat.Short };
                        break;
                    case TipoCampo.Lista:
                        editor = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
                        break;
                    default:
                        editor = new TextBox();
                        break;
                }
                editor.Location = new Point(16, y + 20);
                editor.Width = 280;
                painel.Controls.Add(editor);
                editores[c.Coluna] = editor;
                y += 56;
            }

            y += 8;
            var btnNovo = CriarBotao("Novo", 16, y, (s, e) => Limpar());
            var btnSalvar = CriarBotao("Salvar", 158, y, (s, e) => Salvar());
            var btnExcluir = CriarBotao("Excluir", 16, y + 44, (s, e) => Excluir());
            var btnFechar = CriarBotao("Fechar", 158, y + 44, (s, e) => Close());
            painel.Controls.AddRange(new Control[] { btnNovo, btnSalvar, btnExcluir, btnFechar });

            // ---- Área de exibição (direita) ----
            var direita = new Panel { Dock = DockStyle.Fill, Padding = new Padding(8, 8, 16, 16) };
            var barraBusca = new Panel { Dock = DockStyle.Top, Height = 40 };
            barraBusca.Controls.Add(new Label { Text = "Pesquisar:", Location = new Point(0, 10), AutoSize = true });
            txtBusca = new TextBox { Location = new Point(80, 6), Width = 320 };
            txtBusca.TextChanged += (s, e) => Filtrar();
            barraBusca.Controls.Add(txtBusca);
            var btnAtualizar = CriarBotao("Atualizar", 412, 3, (s, e) => CarregarGrid());
            barraBusca.Controls.Add(btnAtualizar);

            grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                RowHeadersVisible = false
            };
            grid.CellClick += (s, e) => { if (e.RowIndex >= 0) PreencherCampos(e.RowIndex); };

            direita.Controls.Add(grid);
            direita.Controls.Add(barraBusca);

            Controls.Add(direita);
            Controls.Add(painel);
            Controls.Add(lblTitulo);
        }

        private Button CriarBotao(string texto, int x, int y, EventHandler clique)
        {
            var b = new Button { Text = texto, Location = new Point(x, y), Size = new Size(134, 36) };
            b.Click += clique;
            return b;
        }

        private void CarregarListas()
        {
            try
            {
                using (var conn = new MySqlConnection(ConnectionString))
                {
                    conn.Open();
                    foreach (var c in campos)
                    {
                        if (c.Tipo != TipoCampo.Lista) continue;
                        var dt = new DataTable();
                        new MySqlDataAdapter(c.SqlLista, conn).Fill(dt);
                        var combo = (ComboBox)editores[c.Coluna];
                        combo.DataSource = dt;
                        combo.ValueMember = dt.Columns[0].ColumnName;
                        combo.DisplayMember = dt.Columns[1].ColumnName;
                        combo.SelectedIndex = -1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar listas: " + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CarregarGrid()
        {
            try
            {
                using (var conn = new MySqlConnection(ConnectionString))
                {
                    dados = new DataTable();
                    new MySqlDataAdapter(sqlExibir, conn).Fill(dados);
                    grid.DataSource = dados;
                }
                Filtrar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar dados: " + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Filtrar()
        {
            if (dados == null) return;
            string termo = txtBusca.Text.Replace("'", "''").Trim();
            if (termo == "") { dados.DefaultView.RowFilter = ""; return; }
            var partes = new List<string>();
            foreach (DataColumn col in dados.Columns)
                partes.Add(string.Format("CONVERT([{0}], System.String) LIKE '%{1}%'", col.ColumnName, termo));
            dados.DefaultView.RowFilter = string.Join(" OR ", partes);
        }

        private void PreencherCampos(int linha)
        {
            var id = grid.Rows[linha].Cells[0].Value;
            if (id == null) return;
            try
            {
                using (var conn = new MySqlConnection(ConnectionString))
                {
                    conn.Open();
                    var cmd = new MySqlCommand("SELECT * FROM " + tabela + " WHERE " + chave + " = @id", conn);
                    cmd.Parameters.AddWithValue("@id", id);
                    using (var r = cmd.ExecuteReader())
                    {
                        if (!r.Read()) return;
                        txtCodigo.Text = r[chave].ToString();
                        foreach (var c in campos)
                        {
                            object v = r[c.Coluna];
                            var ed = editores[c.Coluna];
                            if (ed is DateTimePicker)
                                ((DateTimePicker)ed).Value = v == DBNull.Value ? DateTime.Today : Convert.ToDateTime(v);
                            else if (ed is ComboBox)
                                ((ComboBox)ed).SelectedValue = v == DBNull.Value ? (object)null : v;
                            else
                                ed.Text = v == DBNull.Value ? "" : Convert.ToString(v, CultureInfo.CurrentCulture);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao abrir registro: " + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Limpar()
        {
            txtCodigo.Text = "";
            foreach (var par in editores)
            {
                if (par.Value is DateTimePicker) ((DateTimePicker)par.Value).Value = DateTime.Today;
                else if (par.Value is ComboBox) ((ComboBox)par.Value).SelectedIndex = -1;
                else par.Value.Text = "";
            }
            grid.ClearSelection();
        }

        private bool LerValor(CampoCadastro c, out object valor)
        {
            var ed = editores[c.Coluna];
            valor = DBNull.Value;
            switch (c.Tipo)
            {
                case TipoCampo.Data:
                    valor = ((DateTimePicker)ed).Value.Date; return true;
                case TipoCampo.Lista:
                    var sv = ((ComboBox)ed).SelectedValue;
                    if (sv == null) { if (c.Obrigatorio) return Aviso(c); return true; }
                    valor = sv; return true;
                case TipoCampo.Inteiro:
                    if (ed.Text.Trim() == "") { if (c.Obrigatorio) return Aviso(c); return true; }
                    int i; if (!int.TryParse(ed.Text.Trim(), out i)) return Aviso(c, "deve ser um número inteiro");
                    valor = i; return true;
                case TipoCampo.Decimal:
                    if (ed.Text.Trim() == "") { if (c.Obrigatorio) return Aviso(c); return true; }
                    decimal d; if (!decimal.TryParse(ed.Text.Trim(), NumberStyles.Number, CultureInfo.CurrentCulture, out d)) return Aviso(c, "deve ser um valor numérico");
                    valor = d; return true;
                default:
                    if (ed.Text.Trim() == "") { if (c.Obrigatorio) return Aviso(c); return true; }
                    valor = ed.Text.Trim(); return true;
            }
        }

        private bool Aviso(CampoCadastro c, string motivo = "é obrigatório")
        {
            MessageBox.Show("O campo \"" + c.Rotulo + "\" " + motivo + ".", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            editores[c.Coluna].Focus();
            return false;
        }

        private void Salvar()
        {
            var valores = new Dictionary<string, object>();
            foreach (var c in campos)
            {
                object v;
                if (!LerValor(c, out v)) return;
                valores[c.Coluna] = v;
            }

            bool novo = txtCodigo.Text == "";
            var cols = new List<string>();
            var pars = new List<string>();
            var sets = new List<string>();
            foreach (var c in campos)
            {
                cols.Add(c.Coluna); pars.Add("@" + c.Coluna); sets.Add(c.Coluna + " = @" + c.Coluna);
            }
            string sql = novo
                ? "INSERT INTO " + tabela + " (" + string.Join(", ", cols) + ") VALUES (" + string.Join(", ", pars) + ")"
                : "UPDATE " + tabela + " SET " + string.Join(", ", sets) + " WHERE " + chave + " = @id";

            try
            {
                using (var conn = new MySqlConnection(ConnectionString))
                {
                    conn.Open();
                    var cmd = new MySqlCommand(sql, conn);
                    foreach (var p in valores) cmd.Parameters.AddWithValue("@" + p.Key, p.Value);
                    if (!novo) cmd.Parameters.AddWithValue("@id", txtCodigo.Text);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show(novo ? "Cadastrado com sucesso!" : "Alterado com sucesso!", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpar();
                CarregarGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao salvar: " + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Excluir()
        {
            if (txtCodigo.Text == "")
            {
                MessageBox.Show("Selecione um registro na tabela para excluir.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (MessageBox.Show("Deseja realmente excluir este registro?", Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;
            try
            {
                using (var conn = new MySqlConnection(ConnectionString))
                {
                    conn.Open();
                    var cmd = new MySqlCommand("DELETE FROM " + tabela + " WHERE " + chave + " = @id", conn);
                    cmd.Parameters.AddWithValue("@id", txtCodigo.Text);
                    cmd.ExecuteNonQuery();
                }
                Limpar();
                CarregarGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir (o registro pode estar em uso): " + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ================== Telas prontas (conforme o banco Estoque) ==================

        private const string ListaStatus = "SELECT 'ativo' AS v, 'ativo' AS t UNION ALL SELECT 'inativo', 'inativo'";
        private const string ListaFornecedores = "SELECT cd_fornecedor, nm_fornecedor FROM fornecedores ORDER BY nm_fornecedor";
        private const string ListaFuncionarios = "SELECT cd_funcionario, nm_funcionario FROM Funcionarios ORDER BY nm_funcionario";
        private const string ListaProdutos = "SELECT cd_produto, nm_produto FROM Produtos ORDER BY nm_produto";

        public static CadastroTabela Fornecedores()
        {
            return new CadastroTabela("Cadastro de Fornecedores", "fornecedores", "cd_fornecedor",
                "SELECT cd_fornecedor AS Código, nm_fornecedor AS Fornecedor, ds_telefone AS Telefone, ds_email AS Email FROM fornecedores ORDER BY nm_fornecedor",
                new List<CampoCadastro>
                {
                    new CampoCadastro("nm_fornecedor", "Nome do fornecedor", TipoCampo.Texto, true),
                    new CampoCadastro("ds_telefone", "Telefone", TipoCampo.Texto, true),
                    new CampoCadastro("ds_email", "E-mail", TipoCampo.Texto, true)
                });
        }

        public static CadastroTabela Categorias()
        {
            return new CadastroTabela("Cadastro de Categorias", "Categorias", "cd_categoria",
                "SELECT cd_categoria AS Código, nm_categoria AS Categoria, ds_categoria AS Descrição, status AS Status FROM Categorias ORDER BY nm_categoria",
                new List<CampoCadastro>
                {
                    new CampoCadastro("nm_categoria", "Nome da categoria", TipoCampo.Texto, true),
                    new CampoCadastro("ds_categoria", "Descrição", TipoCampo.Texto),
                    new CampoCadastro("status", "Status", TipoCampo.Lista, true, ListaStatus)
                });
        }

        public static CadastroTabela Produtos()
        {
            return new CadastroTabela("Cadastro de Produtos", "Produtos", "cd_produto",
                @"SELECT cd_produto AS Código, nm_produto AS Produto, vl_produto AS Valor,
                         dt_validade_produto AS Validade, ds_produto AS Descrição, qt_estoque AS Estoque
                  FROM Produtos ORDER BY nm_produto",
                new List<CampoCadastro>
                {
                    new CampoCadastro("nm_produto", "Nome do produto", TipoCampo.Texto, true),
                    new CampoCadastro("vl_produto", "Valor (R$)", TipoCampo.Decimal, true),
                    new CampoCadastro("dt_validade_produto", "Validade", TipoCampo.Data, true),
                    new CampoCadastro("ds_produto", "Descrição", TipoCampo.Texto, true),
                    new CampoCadastro("qt_estoque", "Quantidade em estoque", TipoCampo.Inteiro, true)
                });
        }

        public static CadastroTabela ProdutoCategoria()
        {
            return new CadastroTabela("Produtos por Categoria", "produto_categoria", "id_produto_categoria",
                @"SELECT pc.id_produto_categoria AS Código, p.nm_produto AS Produto, c.nm_categoria AS Categoria
                  FROM produto_categoria pc
                  INNER JOIN Produtos p ON p.cd_produto = pc.id_produto
                  INNER JOIN Categorias c ON c.cd_categoria = pc.id_categoria
                  ORDER BY p.nm_produto",
                new List<CampoCadastro>
                {
                    new CampoCadastro("id_produto", "Produto", TipoCampo.Lista, true, ListaProdutos),
                    new CampoCadastro("id_categoria", "Categoria", TipoCampo.Lista, true,
                        "SELECT cd_categoria, nm_categoria FROM Categorias WHERE status = 'ativo' ORDER BY nm_categoria")
                });
        }

        public static CadastroTabela Funcionarios()
        {
            return new CadastroTabela("Cadastro de Funcionários", "Funcionarios", "cd_funcionario",
                @"SELECT cd_funcionario AS Código, nm_funcionario AS Nome, dt_nascimento AS Nascimento,
                         ds_telefone AS Telefone, ds_email AS Email, ds_cargo AS Cargo, status AS Status
                  FROM Funcionarios ORDER BY nm_funcionario",
                new List<CampoCadastro>
                {
                    new CampoCadastro("nm_funcionario", "Nome", TipoCampo.Texto, true),
                    new CampoCadastro("dt_nascimento", "Data de nascimento", TipoCampo.Data, true),
                    new CampoCadastro("ds_telefone", "Telefone", TipoCampo.Texto),
                    new CampoCadastro("ds_email", "E-mail", TipoCampo.Texto),
                    new CampoCadastro("ds_cargo", "Cargo", TipoCampo.Lista, true,
                        "SELECT 'admin' AS v, 'admin' AS t UNION ALL SELECT 'vendedor', 'vendedor' UNION ALL SELECT 'estoquista', 'estoquista'"),
                    new CampoCadastro("status", "Status", TipoCampo.Lista, true, ListaStatus),
                    new CampoCadastro("ds_senha", "Senha", TipoCampo.Texto, true)
                });
        }

        public static CadastroTabela Usuarios()
        {
            return new CadastroTabela("Cadastro de Usuários", "Usuarios", "cd_usuario",
                @"SELECT cd_usuario AS Código, nm_usuario AS Nome, dt_nascimento AS Nascimento,
                         ds_telefone AS Telefone, ds_email AS Email
                  FROM Usuarios ORDER BY nm_usuario",
                new List<CampoCadastro>
                {
                    new CampoCadastro("nm_usuario", "Nome", TipoCampo.Texto, true),
                    new CampoCadastro("dt_nascimento", "Data de nascimento", TipoCampo.Data, true),
                    new CampoCadastro("ds_telefone", "Telefone", TipoCampo.Texto),
                    new CampoCadastro("ds_email", "E-mail", TipoCampo.Texto)
                });
        }

        public static CadastroTabela Compras()
        {
            return new CadastroTabela("Cadastro de Compras", "compras", "cd_compra",
                @"SELECT c.cd_compra AS Código, c.dt_compra AS Data, f.nm_fornecedor AS Fornecedor,
                         fu.nm_funcionario AS Funcionário, c.vl_total AS Total
                  FROM compras c
                  INNER JOIN fornecedores f ON f.cd_fornecedor = c.id_fornecedor
                  INNER JOIN Funcionarios fu ON fu.cd_funcionario = c.id_funcionario
                  ORDER BY c.dt_compra DESC",
                new List<CampoCadastro>
                {
                    new CampoCadastro("dt_compra", "Data da compra", TipoCampo.Data, true),
                    new CampoCadastro("id_fornecedor", "Fornecedor", TipoCampo.Lista, true, ListaFornecedores),
                    new CampoCadastro("id_funcionario", "Funcionário", TipoCampo.Lista, true, ListaFuncionarios),
                    new CampoCadastro("vl_total", "Valor total (R$)", TipoCampo.Decimal, true)
                });
        }

        public static CadastroTabela ItensCompra()
        {
            return new CadastroTabela("Itens das Compras", "itens_compra", "id_item_compra",
                @"SELECT ic.id_item_compra AS Código, c.cd_compra AS Compra, p.nm_produto AS Produto,
                         ic.qt_produto AS Quantidade, ic.vl_unitario AS `Valor unit.`,
                         (ic.qt_produto * ic.vl_unitario) AS Subtotal
                  FROM itens_compra ic
                  INNER JOIN compras c ON c.cd_compra = ic.id_compra
                  INNER JOIN Produtos p ON p.cd_produto = ic.id_produto
                  ORDER BY c.cd_compra DESC",
                new List<CampoCadastro>
                {
                    new CampoCadastro("id_compra", "Compra", TipoCampo.Lista, true,
                        "SELECT cd_compra, CONCAT('Nº ', cd_compra, ' - ', DATE_FORMAT(dt_compra, '%d/%m/%Y')) FROM compras ORDER BY cd_compra DESC"),
                    new CampoCadastro("id_produto", "Produto", TipoCampo.Lista, true, ListaProdutos),
                    new CampoCadastro("qt_produto", "Quantidade", TipoCampo.Inteiro, true),
                    new CampoCadastro("vl_unitario", "Valor unitário (R$)", TipoCampo.Decimal, true)
                });
        }

        public static CadastroTabela Vendas()
        {
            return new CadastroTabela("Cadastro de Vendas", "vendas", "cd_venda",
                @"SELECT v.cd_venda AS Código, v.dt_venda AS Data, fu.nm_funcionario AS Funcionário, v.vl_total AS Total
                  FROM vendas v INNER JOIN Funcionarios fu ON fu.cd_funcionario = v.id_funcionario
                  ORDER BY v.dt_venda DESC",
                new List<CampoCadastro>
                {
                    new CampoCadastro("dt_venda", "Data da venda", TipoCampo.Data, true),
                    new CampoCadastro("id_funcionario", "Funcionário", TipoCampo.Lista, true, ListaFuncionarios),
                    new CampoCadastro("vl_total", "Valor total (R$)", TipoCampo.Decimal, true)
                });
        }

        public static CadastroTabela ItensVenda()
        {
            return new CadastroTabela("Itens das Vendas", "itens_venda", "id_item_venda",
                @"SELECT iv.id_item_venda AS Código, v.cd_venda AS Venda, p.nm_produto AS Produto,
                         iv.quantidade AS Quantidade, iv.vl_unitario AS `Valor unit.`,
                         (iv.quantidade * iv.vl_unitario) AS Subtotal
                  FROM itens_venda iv
                  INNER JOIN vendas v ON v.cd_venda = iv.id_venda
                  INNER JOIN Produtos p ON p.cd_produto = iv.id_produto
                  ORDER BY v.cd_venda DESC",
                new List<CampoCadastro>
                {
                    new CampoCadastro("id_venda", "Venda", TipoCampo.Lista, true,
                        "SELECT cd_venda, CONCAT('Nº ', cd_venda, ' - ', DATE_FORMAT(dt_venda, '%d/%m/%Y')) FROM vendas ORDER BY cd_venda DESC"),
                    new CampoCadastro("id_produto", "Produto", TipoCampo.Lista, true, ListaProdutos),
                    new CampoCadastro("quantidade", "Quantidade", TipoCampo.Inteiro, true),
                    new CampoCadastro("vl_unitario", "Valor unitário (R$)", TipoCampo.Decimal, true)
                });
        }
    }
}

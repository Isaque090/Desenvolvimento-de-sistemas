﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace conversor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            contextMenuStrip1.Show(button1, new Point(0, button1.Height));
        }

        private void contextMenuStrip2_Opening(object sender, CancelEventArgs e)
        {
            
        }

        private void grausToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button1.Text = "Celsios";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            contextMenuStrip2.Show(button2, new Point(0, button2.Height));
        }

        private void firehatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button1.Text = "Fahrenheit";
        }

        private void kelvinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button1.Text = "Kelvin";
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            button2.Text = "Celsios";
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            button2.Text = "Fahrenheit";
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            button2.Text = "Kelvin";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button1.Text == "Celsios" &&
            button2.Text == "Fahrenheit")
            {
                double V1, V2;

                V1 = double.Parse(textBox2.Text);
                V2 = double.Parse(textBox1.Text);

                textBox1.Text = ((V1 * 1.8) + 32).ToString();
            }

           else if (button1.Text == "Celsios" &&
            button2.Text == "Kelvin")
            {
                double V1, V2;

                V1 = double.Parse(textBox2.Text);
                V2 = double.Parse(textBox1.Text);

                textBox1.Text = (V1 + 273.15).ToString();
            }
          else  if (button1.Text == "Kelvin" && button2.Text == "Celsios" 
           )
            {
                double V1;

                V1 = double.Parse(textBox2.Text);
              

                textBox1.Text =( V1 - 273.15).ToString();
            }
            else if (button1.Text == "Kelvin" &&
 button2.Text == "Fahrenheit")
            {
                double V1;

                V1 = double.Parse(textBox2.Text);


                textBox1.Text = (((V1- 32) / 1.8) + 273.15).ToString();
            }
            else if (button2.Text == "Celsios" &&
button1.Text == "Fahrenheit")
            {
                double V1;

                V1 = double.Parse(textBox2.Text);


                textBox1.Text = ((V1 - 32) / 1.8).ToString();
            }

            else if (button1.Text ==
              button2.Text)
            {
                double V1;

                V1 = double.Parse(textBox2.Text);
              

                textBox1.Text =V1.ToString() ;
            }

            }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }
    }
}
